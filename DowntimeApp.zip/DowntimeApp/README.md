# Downtime (device-owner app)

Suspends selected apps on a daily schedule using AlarmManager + DevicePolicyManager.
Settings (com.android.settings, com.android.system, SystemUI, the device's resolved Settings app) can never be suspended.
The manifest has `android:testOnly="true"`.

## Build
Push this folder to a GitHub repo -> Actions -> "Build APK" -> download the `downtime-debug-apk` artifact.
Or locally (JDK 17, Android SDK, Gradle 8.9+): `gradle assembleDebug`

## Install
    adb install -t app-debug.apk        # -t is required for testOnly apps
    adb shell dpm set-device-owner com.example.downtime/.AdminReceiver

If it says accounts exist, remove accounts temporarily (or use a fresh/factory-reset device).

## Remove device owner
- In the app: "Remove device owner".
- Fallback from a computer (works because of testOnly):
      adb shell dpm remove-active-admin com.example.downtime/.AdminReceiver
