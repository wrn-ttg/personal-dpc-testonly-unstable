package com.example.downtime;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String a = intent.getAction();
        if (Store.enabled(context) && Policy.isOwner(context)) {
            if (Scheduler.ACTION_START.equals(a)) {
                Policy.unsuspendAll(context);
                Policy.suspend(context);
            } else if (Scheduler.ACTION_END.equals(a)) {
                Policy.unsuspendAll(context);
            }
        }
        Scheduler.schedule(context); // queue tomorrow's alarms
    }
}
