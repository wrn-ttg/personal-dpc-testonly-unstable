package com.example.downtime;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class Policy {
    private Policy() {}

    /** Packages that can NEVER be given downtime. */
    private static final Set<String> BLOCKED = new HashSet<>(Arrays.asList(
            "android",
            "com.android.settings",
            "com.android.system",
            "com.android.systemui",
            "com.android.providers.settings",
            "com.android.phone",
            "com.android.shell"
    ));

    private static DevicePolicyManager dpm(Context c) {
        return (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
    }

    private static ComponentName admin(Context c) {
        return new ComponentName(c, AdminReceiver.class);
    }

    /** The package(s) that answer the Settings intent (covers OEM settings apps). */
    private static Set<String> settingsPackages(Context c) {
        Set<String> out = new HashSet<>();
        out.add("com.android.settings");
        List<ResolveInfo> list = c.getPackageManager()
                .queryIntentActivities(new Intent(Settings.ACTION_SETTINGS), 0);
        for (ResolveInfo ri : list) {
            if (ri.activityInfo != null) out.add(ri.activityInfo.packageName);
        }
        return out;
    }

    static boolean isProtected(Context c, String pkg) {
        if (pkg == null || pkg.isEmpty()) return true;
        if (pkg.equals(c.getPackageName())) return true;
        if (BLOCKED.contains(pkg)) return true;
        if (pkg.startsWith("com.android.settings.")) return true;
        return settingsPackages(c).contains(pkg);
    }

    static boolean isOwner(Context c) {
        return dpm(c).isDeviceOwnerApp(c.getPackageName());
    }

    /** Suspends the selected apps. Returns count suspended, or -1 if not device owner. */
    static int suspend(Context c) {
        if (!isOwner(c)) return -1;
        List<String> list = new ArrayList<>();
        for (String p : Store.packages(c)) {
            if (!isProtected(c, p)) list.add(p);
        }
        if (list.isEmpty()) return 0;
        String[] failed = dpm(c).setPackagesSuspended(admin(c), list.toArray(new String[0]), true);
        Set<String> done = new HashSet<>(list);
        if (failed != null) done.removeAll(Arrays.asList(failed));
        Store.setSuspended(c, done);
        return done.size();
    }

    /** Lifts downtime for everything we suspended (and always keeps Settings available). */
    static void unsuspendAll(Context c) {
        if (!isOwner(c)) return;
        Set<String> s = new HashSet<>(Store.suspended(c));
        s.addAll(Store.packages(c));
        s.addAll(settingsPackages(c));
        s.remove(c.getPackageName());
        dpm(c).setPackagesSuspended(admin(c), s.toArray(new String[0]), false);
        Store.setSuspended(c, new HashSet<String>());
    }

    static boolean inWindow(int startMin, int endMin) {
        Calendar cal = Calendar.getInstance();
        int now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        if (startMin == endMin) return false;
        if (startMin < endMin) return now >= startMin && now < endMin;
        return now >= startMin || now < endMin; // wraps midnight
    }

    /** Makes the suspended state match the schedule and the current time. */
    static void sync(Context c) {
        if (!isOwner(c)) return;
        unsuspendAll(c);
        if (Store.enabled(c) && inWindow(Store.start(c), Store.end(c))) suspend(c);
    }

    /** Lifts downtime, cancels alarms, then gives up device-owner status. */
    @SuppressWarnings("deprecation")
    static String removeOwner(Context c) {
        if (!isOwner(c)) return "Not device owner";
        try {
            Scheduler.cancel(c);
            Store.setEnabled(c, false);
            unsuspendAll(c);
            dpm(c).clearDeviceOwnerApp(c.getPackageName());
            return "Device owner removed";
        } catch (Exception e) {
            return "Failed: " + e.getMessage();
        }
    }
}
