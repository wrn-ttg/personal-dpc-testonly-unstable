package com.example.downtime;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

final class Store {
    private Store() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("downtime", Context.MODE_PRIVATE);
    }

    static Set<String> packages(Context c) {
        return new HashSet<>(p(c).getStringSet("pkgs", new HashSet<String>()));
    }

    static Set<String> suspended(Context c) {
        return new HashSet<>(p(c).getStringSet("susp", new HashSet<String>()));
    }

    static void setSuspended(Context c, Set<String> s) {
        p(c).edit().putStringSet("susp", new HashSet<>(s)).apply();
    }

    static boolean enabled(Context c) { return p(c).getBoolean("enabled", false); }
    static int start(Context c) { return p(c).getInt("start", 22 * 60); }
    static int end(Context c) { return p(c).getInt("end", 7 * 60); }

    static void setEnabled(Context c, boolean on) {
        p(c).edit().putBoolean("enabled", on).apply();
    }

    static void save(Context c, boolean enabled, int start, int end, Set<String> pkgs) {
        p(c).edit()
                .putBoolean("enabled", enabled)
                .putInt("start", start)
                .putInt("end", end)
                .putStringSet("pkgs", new HashSet<>(pkgs))
                .apply();
    }
}
