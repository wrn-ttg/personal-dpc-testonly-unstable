package com.example.downtime;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

final class Scheduler {
    private Scheduler() {}

    static final String ACTION_START = "com.example.downtime.START";
    static final String ACTION_END = "com.example.downtime.END";

    private static AlarmManager am(Context c) {
        return (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    }

    static boolean canExact(Context c) {
        return Build.VERSION.SDK_INT < 31 || am(c).canScheduleExactAlarms();
    }

    private static PendingIntent pi(Context c, int req, String action) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(c, req, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long next(int minutes) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, minutes / 60);
        cal.set(Calendar.MINUTE, minutes % 60);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis() + 1000) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis();
    }

    private static void set(Context c, int req, String action, long at) {
        PendingIntent p = pi(c, req, action);
        if (canExact(c)) {
            am(c).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
        } else {
            am(c).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
        }
    }

    static void cancel(Context c) {
        am(c).cancel(pi(c, 1, ACTION_START));
        am(c).cancel(pi(c, 2, ACTION_END));
    }

    static void schedule(Context c) {
        cancel(c);
        if (!Store.enabled(c)) return;
        set(c, 1, ACTION_START, next(Store.start(c)));
        set(c, 2, ACTION_END, next(Store.end(c)));
    }
}
