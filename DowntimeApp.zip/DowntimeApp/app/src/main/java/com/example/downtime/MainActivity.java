package com.example.downtime;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private TextView status;
    private Button startBtn, endBtn;
    private Switch enabledSw;
    private int startMin, endMin;
    private final Set<String> selected = new HashSet<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        startMin = Store.start(this);
        endMin = Store.end(this);
        selected.addAll(Store.packages(this));

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        sv.addView(root);

        status = new TextView(this);
        root.addView(status);

        enabledSw = new Switch(this);
        enabledSw.setText("Daily downtime schedule");
        enabledSw.setChecked(Store.enabled(this));
        root.addView(enabledSw);

        startBtn = button("", v -> pickTime(true));
        endBtn = button("", v -> pickTime(false));
        root.addView(startBtn);
        root.addView(endBtn);

        root.addView(button("Save & schedule", v -> save()));
        root.addView(button("Suspend selected now", v -> {
            int n = Policy.suspend(this);
            toast(n < 0 ? "Not device owner" : n + " app(s) suspended");
            refresh();
        }));
        root.addView(button("Unsuspend all now", v -> {
            Policy.unsuspendAll(this);
            toast("Downtime lifted");
        }));
        root.addView(button("Remove device owner", v -> confirmRemove()));

        TextView h = new TextView(this);
        h.setText("Apps (Settings is never listed)");
        h.setTextSize(18);
        h.setPadding(0, dp(16), 0, dp(8));
        root.addView(h);
        addApps(root);

        setContentView(sv);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void addApps(LinearLayout root) {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        List<String[]> apps = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (!seen.add(pkg) || Policy.isProtected(this, pkg)) continue;
            apps.add(new String[]{ri.loadLabel(pm).toString(), pkg});
        }
        Collections.sort(apps, (a, c) -> a[0].compareToIgnoreCase(c[0]));
        for (String[] a : apps) {
            CheckBox cb = new CheckBox(this);
            cb.setText(a[0] + "\n" + a[1]);
            cb.setChecked(selected.contains(a[1]));
            cb.setOnCheckedChangeListener((v, on) -> {
                if (on) selected.add(a[1]); else selected.remove(a[1]);
            });
            root.addView(cb);
        }
    }

    private void save() {
        Set<String> clean = new HashSet<>();
        for (String p : selected) {
            if (!Policy.isProtected(this, p)) clean.add(p);
        }
        Store.save(this, enabledSw.isChecked(), startMin, endMin, clean);
        Scheduler.schedule(this);
        Policy.sync(this);
        if (enabledSw.isChecked() && !Scheduler.canExact(this) && Build.VERSION.SDK_INT >= 31) {
            toast("Allow exact alarms for reliable timing");
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
        } else {
            toast("Saved");
        }
        refresh();
    }

    private void pickTime(boolean isStart) {
        int cur = isStart ? startMin : endMin;
        new TimePickerDialog(this, (view, h, m) -> {
            if (isStart) startMin = h * 60 + m; else endMin = h * 60 + m;
            refresh();
        }, cur / 60, cur % 60, true).show();
    }

    private void confirmRemove() {
        new AlertDialog.Builder(this)
                .setTitle("Remove device owner?")
                .setMessage("Downtime is lifted, alarms are cancelled, and this app stops being device owner.")
                .setPositiveButton("Remove", (d, w) -> {
                    toast(Policy.removeOwner(this));
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refresh() {
        startBtn.setText("Start: " + fmt(startMin));
        endBtn.setText("End: " + fmt(endMin));
        if (Policy.isOwner(this)) {
            status.setText("Device owner: yes");
        } else {
            status.setText("Device owner: NO\nRun on a computer:\n"
                    + "adb shell dpm set-device-owner com.example.downtime/.AdminReceiver");
        }
    }

    private static String fmt(int m) {
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
